import React, { useState } from 'react';
import {
  Card,
  CardContent,
  Typography,
  Button,
  CardActions,
  Box,
  Dialog,
  IconButton,
  Paper,
  CircularProgress,
  Tooltip,
  Chip,
} from '@mui/material';
import { Download, Visibility, Close, Edit, Check, Delete } from '@mui/icons-material';
import EditModal from './EditModal';
import { getFullUrl } from '../config/api';

interface PDFCardProps {
  title: string;
  author: string;
  fileSize: number;
  fileUrl: string;
  isAdmin?: boolean;
  isApproved?: boolean;
  onEdit?: (title: string, author: string) => void;
  onApprove?: () => void;
  onDelete?: () => void;
}

export const PDFCard: React.FC<PDFCardProps> = ({
  title,
  author,
  fileSize,
  fileUrl,
  isAdmin = false,
  isApproved = false,
  onEdit,
  onApprove,
  onDelete,
}) => {
  const [previewOpen, setPreviewOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  const handleEdit = (newTitle: string, newAuthor: string) => {
    if (onEdit) {
      onEdit(newTitle, newAuthor);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const iframeStyle = {
    width: '100%',
    height: '100%',
    border: 'none',
  };

  const embedStyle = `
    <style>
      #toolbar { display: none !important; }
      #toolbarContainer { display: none !important; }
      .toolbar { display: none !important; }
      header { display: none !important; }
      #download { display: none !important; }
      #print { display: none !important; }
      #secondaryToolbar { display: none !important; }
    </style>
  `;

  return (
    <>
      <Card
        elevation={1}
        sx={{
          display: 'flex',
          flexDirection: 'column',
          height: '100%',
          transition: 'all 0.3s ease',
          '&:hover': {
            transform: 'translateY(-4px)',
            boxShadow: 4,
          },
          borderRadius: 2,
          overflow: 'hidden',
        }}
      >
        {/* PDF Preview */}
        <Paper
          elevation={0}
          sx={{
            height: { xs: 200, sm: 250, md: 280 },
            width: '100%',
            bgcolor: 'grey.100',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            overflow: 'hidden',
            position: 'relative'
          }}
        >
          <iframe
            src={`${getFullUrl(fileUrl)}#page=1&view=FitH&toolbar=0&navpanes=0&scrollbar=0`}
            style={{
              width: '100%',
              height: '100%',
              border: 'none',
            }}
            title={title}
          />
        </Paper>

        <CardContent sx={{ flexGrow: 1, p: { xs: 1.5, sm: 2 } }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <Typography
              variant="h6"
              sx={{
                fontSize: { xs: '1rem', sm: '1.1rem', md: '1.25rem' },
                fontWeight: 'bold',
                mb: 1,
                flex: 1
              }}
            >
              {title}
            </Typography>
            {isAdmin && (
              <Box sx={{ display: 'flex', gap: 1 }}>
                <Tooltip title="Edit PDF details">
                  <IconButton
                    size="small"
                    onClick={() => setIsEditModalOpen(true)}
                  >
                    <Edit fontSize="small" />
                  </IconButton>
                </Tooltip>
                {!isApproved && (
                  <Tooltip title="Approve PDF">
                    <IconButton
                      size="small"
                      onClick={onApprove}
                      color="success"
                    >
                      <Check fontSize="small" />
                    </IconButton>
                  </Tooltip>
                )}
                <Tooltip title="Delete PDF">
                  <IconButton
                    size="small"
                    onClick={onDelete}
                    color="error"
                  >
                    <Delete fontSize="small" />
                  </IconButton>
                </Tooltip>
              </Box>
            )}
          </Box>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
            Author: {author}
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Size: {formatFileSize(fileSize)}
          </Typography>
          {isAdmin && (
            <Chip
              label={isApproved ? 'Approved' : 'Pending'}
              color={isApproved ? 'success' : 'warning'}
              size="small"
              sx={{ mt: 1 }}
            />
          )}
        </CardContent>

        <CardActions sx={{ p: { xs: 1.5, sm: 2 }, pt: 0, display: 'flex', gap: { xs: 1, sm: 1 }, justifyContent: 'space-between' }}>
          <Button
            size="small"
            variant="outlined"
            startIcon={<Visibility />}
            onClick={() => setPreviewOpen(true)}
            sx={{ 
              flex: 1,
              minWidth: { xs: '90px', sm: '120px' },
              fontSize: { xs: '0.75rem', sm: '0.875rem' }
            }}
          >
            View
          </Button>
          <Button
            size="small"
            variant="contained"
            startIcon={<Download />}
            href={getFullUrl(fileUrl)}
            download
            sx={{ 
              flex: 1,
              minWidth: { xs: '90px', sm: '120px' },
              fontSize: { xs: '0.75rem', sm: '0.875rem' },
              bgcolor: 'primary.main',
              '&:hover': {
                bgcolor: 'primary.dark',
              }
            }}
          >
            Download
          </Button>
        </CardActions>
      </Card>

      {/* Full Preview Dialog */}
      <Dialog
        open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        maxWidth="lg"
        fullWidth
        PaperProps={{
          sx: { bgcolor: 'grey.100', height: 'calc(100vh - 64px)' }
        }}
      >
        <Box sx={{ 
          position: 'relative', 
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
        }}>
          <IconButton
            onClick={() => setPreviewOpen(false)}
            sx={{
              position: 'absolute',
              right: 16,
              top: 16,
              bgcolor: 'white',
              '&:hover': { bgcolor: 'grey.100' },
              zIndex: 10,
            }}
          >
            <Close />
          </IconButton>
          
          <iframe
            src={`${getFullUrl(fileUrl)}#page=1&view=FitH&toolbar=0&navpanes=0&scrollbar=0`}
            style={{
              width: '100%',
              height: '100%',
              border: 'none',
            }}
            title={`${title} Preview`}
          />
        </Box>
      </Dialog>

      {isAdmin && (
        <EditModal
          open={isEditModalOpen}
          onClose={() => setIsEditModalOpen(false)}
          onSave={handleEdit}
          initialTitle={title}
          initialAuthor={author}
        />
      )}
    </>
  );
};

export default PDFCard; 