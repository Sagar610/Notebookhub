const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3001';

export const API_ENDPOINTS = {
  UPLOAD: `${API_BASE_URL}/api/pdfs/upload`,
  PDFS: `${API_BASE_URL}/api/pdfs`,
  PDF: (id: string) => `${API_BASE_URL}/api/pdfs/${id}`,
  LOGIN: `${API_BASE_URL}/api/auth/login`,
  REGISTER: `${API_BASE_URL}/api/auth/register`,
};

export const getFullUrl = (url: string): string => {
  if (url.startsWith('http')) return url;
  return `${API_BASE_URL}${url.startsWith('/') ? '' : '/'}${url}`;
}; 