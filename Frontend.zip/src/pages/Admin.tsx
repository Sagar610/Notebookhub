import React, { useEffect, useState } from 'react';
import {
  Grid,
  Typography,
  Box,
  Container,
  CircularProgress,
  Tabs,
  Tab,
  Paper,
  Alert,
  TextField,
  InputAdornment,
} from '@mui/material';
import { Search as SearchIcon } from '@mui/icons-material';
import { PDFCard } from '../components/PDFCard';
import { pdfService } from '../services/pdfService';
import { PDF } from '../types/pdf';

const Admin: React.FC = () => {
  const [pdfs, setPdfs] = useState<PDF[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tabValue, setTabValue] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const fetchPDFs = async () => {
      try {
        setLoading(true);
        setError(null);
        const allPDFs = await pdfService.getAllPDFs();
        setPdfs(allPDFs);
      } catch (error) {
        console.error('Error fetching PDFs:', error);
        setError(error instanceof Error ? error.message : 'Failed to load PDFs. Please try again later.');
      } finally {
        setLoading(false);
      }
    };

    fetchPDFs();
  }, []);

  const handleApprove = async (id: string) => {
    try {
      setError(null);
      await pdfService.approvePDF(id);
      setPdfs(pdfs.map(pdf => 
        pdf._id === id ? { ...pdf, isApproved: true } : pdf
      ));
    } catch (error) {
      console.error('Error approving PDF:', error);
      setError(error instanceof Error ? error.message : 'Failed to approve PDF. Please try again.');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      setError(null);
      await pdfService.deletePDF(id);
      setPdfs(pdfs.filter(pdf => pdf._id !== id));
    } catch (error) {
      console.error('Error deleting PDF:', error);
      setError(error instanceof Error ? error.message : 'Failed to delete PDF. Please try again.');
    }
  };

  const handleEdit = async (id: string, title: string, author: string) => {
    try {
      setError(null);
      const updatedPDF = await pdfService.updatePDF(id, { title, author });
      setPdfs(pdfs.map(pdf => 
        pdf._id === id ? updatedPDF : pdf
      ));
    } catch (error) {
      console.error('Error updating PDF:', error);
      setError(error instanceof Error ? error.message : 'Failed to update PDF. Please try again.');
    }
  };

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const handleSearchChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(event.target.value.toLowerCase());
  };

  const filterPDFs = (pdfs: PDF[]) => {
    if (!searchQuery) return pdfs;
    
    return pdfs.filter(pdf => 
      pdf.title.toLowerCase().includes(searchQuery) ||
      pdf.author.toLowerCase().includes(searchQuery) ||
      pdf.fileSize.toString().includes(searchQuery) ||
      pdf.status.toLowerCase().includes(searchQuery)
    );
  };

  const pendingPDFs = filterPDFs(pdfs.filter(pdf => !pdf.isApproved));
  const approvedPDFs = filterPDFs(pdfs.filter(pdf => pdf.isApproved));

  return (
    <Container maxWidth="lg">
      <Box sx={{ mb: 4, textAlign: 'center' }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Admin Dashboard
        </Typography>
        <Typography variant="subtitle1" color="text.secondary" gutterBottom>
          Manage and approve submitted PDFs
        </Typography>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <Paper sx={{ p: 2, mb: 3 }}>
        <TextField
          fullWidth
          variant="outlined"
          placeholder="Search by title, author, size, or status..."
          value={searchQuery}
          onChange={handleSearchChange}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
      </Paper>

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <CircularProgress />
        </Box>
      ) : pdfs.length === 0 ? (
        <Box sx={{ textAlign: 'center', mt: 4 }}>
          <Typography variant="h6" color="text.secondary">
            No PDFs available.
          </Typography>
        </Box>
      ) : (
        <Paper sx={{ mt: 2 }}>
          <Tabs
            value={tabValue}
            onChange={handleTabChange}
            indicatorColor="primary"
            textColor="primary"
            centered
            sx={{ borderBottom: 1, borderColor: 'divider' }}
          >
            <Tab 
              label={`Pending (${pendingPDFs.length})`} 
              sx={{ fontWeight: 'medium' }}
            />
            <Tab 
              label={`Approved (${approvedPDFs.length})`}
              sx={{ fontWeight: 'medium' }}
            />
          </Tabs>

          <Box sx={{ p: 3 }}>
            {tabValue === 0 ? (
              pendingPDFs.length === 0 ? (
                <Box sx={{ textAlign: 'center', py: 4 }}>
                  <Typography variant="h6" color="text.secondary">
                    {searchQuery ? 'No matching pending PDFs found' : 'No pending PDFs for approval'}
                  </Typography>
                </Box>
              ) : (
                <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, gap: 3 }}>
                  {pendingPDFs.map((pdf) => (
                    <Box key={pdf._id}>
                      <PDFCard
                        title={pdf.title}
                        author={pdf.author}
                        fileSize={pdf.fileSize}
                        fileUrl={pdf.fileUrl}
                        isAdmin={true}
                        isApproved={pdf.isApproved}
                        onEdit={(newTitle, newAuthor) => handleEdit(pdf._id, newTitle, newAuthor)}
                        onApprove={() => handleApprove(pdf._id)}
                        onDelete={() => handleDelete(pdf._id)}
                      />
                    </Box>
                  ))}
                </Box>
              )
            ) : (
              approvedPDFs.length === 0 ? (
                <Box sx={{ textAlign: 'center', py: 4 }}>
                  <Typography variant="h6" color="text.secondary">
                    {searchQuery ? 'No matching approved PDFs found' : 'No approved PDFs yet'}
                  </Typography>
                </Box>
              ) : (
                <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr', md: '1fr 1fr 1fr' }, gap: 3 }}>
                  {approvedPDFs.map((pdf) => (
                    <Box key={pdf._id}>
                      <PDFCard
                        title={pdf.title}
                        author={pdf.author}
                        fileSize={pdf.fileSize}
                        fileUrl={pdf.fileUrl}
                        isAdmin={true}
                        isApproved={pdf.isApproved}
                        onEdit={(newTitle, newAuthor) => handleEdit(pdf._id, newTitle, newAuthor)}
                        onDelete={() => handleDelete(pdf._id)}
                      />
                    </Box>
                  ))}
                </Box>
              )
            )}
          </Box>
        </Paper>
      )}
    </Container>
  );
};

export default Admin; 