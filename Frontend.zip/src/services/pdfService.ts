import { API_ENDPOINTS } from '../config/api';
import { PDF } from '../types/pdf';

const getAuthHeaders = () => {
  const token = localStorage.getItem('token');
  return {
    'Content-Type': 'application/json',
    ...(token ? { 'Authorization': `Bearer ${token}` } : {})
  };
};

export const pdfService = {
  // Public functions (no authentication required)
  async uploadPDF(file: File, title: string, author: string): Promise<PDF> {
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('title', title);
      formData.append('author', author);

      const response = await fetch(API_ENDPOINTS.UPLOAD, {
        method: 'POST',
        body: formData
      });

      if (!response.ok) {
        let errorMessage = 'Failed to upload PDF';
        try {
          const errorData = await response.json();
          errorMessage = errorData.message || 'Failed to upload PDF';
        } catch (e) {
          errorMessage = `Upload failed: ${response.statusText}`;
        }
        throw new Error(errorMessage);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('Error uploading PDF:', error);
      throw error instanceof Error ? error : new Error('Failed to upload PDF. Please try again.');
    }
  },

  async getPDFs(): Promise<PDF[]> {
    try {
      const response = await fetch(API_ENDPOINTS.PDFS);
      if (!response.ok) {
        throw new Error('Failed to fetch PDFs');
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching PDFs:', error);
      throw error;
    }
  },

  // Admin functions (require authentication)
  async getAllPDFs(): Promise<PDF[]> {
    try {
      const response = await fetch(`${API_ENDPOINTS.PDFS}/admin`, {
        headers: getAuthHeaders()
      });
      
      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('Authentication required. Please log in.');
        }
        throw new Error('Failed to fetch PDFs');
      }
      return await response.json();
    } catch (error) {
      console.error('Error fetching PDFs:', error);
      throw error;
    }
  },

  async updatePDF(id: string, data: { title?: string; author?: string; isApproved?: boolean }): Promise<PDF> {
    try {
      const response = await fetch(API_ENDPOINTS.PDF(id), {
        method: 'PATCH',
        headers: getAuthHeaders(),
        body: JSON.stringify(data)
      });

      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('Authentication required. Please log in.');
        }
        throw new Error('Failed to update PDF');
      }

      return await response.json();
    } catch (error) {
      console.error('Error updating PDF:', error);
      throw error;
    }
  },

  async approvePDF(id: string, updates?: { title?: string; author?: string }): Promise<PDF> {
    try {
      const response = await fetch(`${API_ENDPOINTS.PDF(id)}/approve`, {
        method: 'PATCH',
        headers: getAuthHeaders(),
        body: JSON.stringify({ isApproved: true, ...updates })
      });

      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('Authentication required. Please log in.');
        }
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to approve PDF');
      }

      return await response.json();
    } catch (error) {
      console.error('Error approving PDF:', error);
      throw error;
    }
  },

  async deletePDF(id: string): Promise<void> {
    try {
      const response = await fetch(API_ENDPOINTS.PDF(id), {
        method: 'DELETE',
        headers: getAuthHeaders()
      });

      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('Authentication required. Please log in.');
        }
        throw new Error('Failed to delete PDF');
      }
    } catch (error) {
      console.error('Error deleting PDF:', error);
      throw error;
    }
  }
}; 