import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import multer from 'multer';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const port = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/handwrittennotes')
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

// PDF Model
const pdfSchema = new mongoose.Schema({
  title: String,
  author: String,
  fileUrl: String,
  fileSize: Number,
  isApproved: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

const PDF = mongoose.model('PDF', pdfSchema);

// Multer configuration for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage });

// Routes
app.get('/api/pdfs', async (req, res) => {
  try {
    const pdfs = await PDF.find({ isApproved: true }).sort({ createdAt: -1 });
    res.json(pdfs);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching PDFs' });
  }
});

app.get('/api/pdfs/admin', async (req, res) => {
  try {
    const pdfs = await PDF.find().sort({ createdAt: -1 });
    res.json(pdfs);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching PDFs' });
  }
});

app.post('/api/pdfs/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const pdf = new PDF({
      title: req.body.title,
      author: req.body.author,
      fileUrl: `/uploads/${req.file.filename}`,
      fileSize: req.file.size,
      isApproved: false
    });

    await pdf.save();
    res.json(pdf);
  } catch (error) {
    res.status(500).json({ error: 'Error uploading PDF' });
  }
});

app.patch('/api/pdfs/:id/approve', async (req, res) => {
  try {
    const pdf = await PDF.findByIdAndUpdate(
      req.params.id,
      { isApproved: true },
      { new: true }
    );
    res.json(pdf);
  } catch (error) {
    res.status(500).json({ error: 'Error approving PDF' });
  }
});

app.patch('/api/pdfs/:id', async (req, res) => {
  try {
    const pdf = await PDF.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.json(pdf);
  } catch (error) {
    res.status(500).json({ error: 'Error updating PDF' });
  }
});

app.delete('/api/pdfs/:id', async (req, res) => {
  try {
    await PDF.findByIdAndDelete(req.params.id);
    res.json({ message: 'PDF deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error deleting PDF' });
  }
});

// Serve static files
app.use('/uploads', express.static('uploads'));

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
}); 